package prr.clients.notifications;

import prr.terminals.*;

public class AppNotification extends Notification {
    public AppNotification(Terminal terminal, String type) {
        super(terminal, type);
    }
}