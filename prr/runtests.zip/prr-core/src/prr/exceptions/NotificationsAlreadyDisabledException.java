package prr.exceptions;

public class NotificationsAlreadyDisabledException extends Exception {
    /* This exception is used to notify the app when notifications are already disabled */
}