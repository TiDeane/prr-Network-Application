package prr.exceptions;

public class NoOngoingCommunicationException extends Exception {
    /* should not happen */
}