package prr.exceptions;

public class NotificationsAlreadyEnabledException extends Exception {
    /* This exception is used to notify the app when notifications are already enabled */
}