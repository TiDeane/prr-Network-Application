package prr.exceptions;

public class TerminalAlreadyInStateException extends Exception {
    /* This exception is used to notify the app when the Terminal is already in the desired state */
}