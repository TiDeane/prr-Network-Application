package prr.app.lookups;

/**
 * Messages.
 */
interface Message {

	// EMPTY
	
}